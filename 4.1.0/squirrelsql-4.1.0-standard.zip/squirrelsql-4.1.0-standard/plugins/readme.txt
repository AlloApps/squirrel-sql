Unzip your plugins here
